from tkinter import *
from tkinter import filedialog as fd
import pygame as pg
import pyttsx3

WIDTH=1000
HEIGHT=1000